--#SET TERMINATOR @

connect to hvdb @

CREATE OR REPLACE PROCEDURE CLEANUP_EXPIRED_TOKENS( IN maxCount INT ,
                                                    OUT expiredCount INT ,
                                                    OUT cleanupCount INT)
LANGUAGE SQL
MODIFIES SQL DATA
AUTONOMOUS
BEGIN
DECLARE target bigint;

SET target = ( SELECT
        BIGINT('1000')*((BIGINT('86400')*(DAYS(CURRENT TIMESTAMP - CURRENT TIMEZONE)-DAYS('1970-01-01')))
+ MIDNIGHT_SECONDS(CURRENT TIMESTAMP - CURRENT TIMEZONE))
FROM SYSIBM.SYSDUMMY1) ;
select count(*) INTO expiredCount from OAUTHDBSCHEMA.OAUTH20CACHE
WHERE expires > 0 and expires < target;
SET cleanupCount = 0;

L0: WHILE (cleanupCount < maxCount) DO
    L1: FOR expireID AS
    SELECT lookupkey
    FROM OAUTHDBSCHEMA.OAUTH20CACHE
    WHERE expires > 0 and expires < target FETCH FIRST 1000 ROWS ONLY
    DO
        DELETE FROM OAUTHDBSCHEMA.OAUTH20CACHE WHERE lookupkey = expireID.lookupkey;
        SET cleanupCount = cleanupCount + 1;
        IF cleanupCount >= maxCount THEN
            LEAVE L1;
        END IF;
    END FOR;
    COMMIT;
END WHILE;

END @

CALL CLEANUP_EXPIRED_TOKENS(1000000, ?, ?) @

